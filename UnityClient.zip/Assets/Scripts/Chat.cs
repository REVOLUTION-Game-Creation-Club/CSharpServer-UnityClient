﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class Chat : MonoBehaviour {

    //[SerializeField]
    //public static Text txtName;
    //[SerializeField]
    //public Text txtMessage;
    //[SerializeField]
    //Text forPrint;
    //[SerializeField]
    //Scrollbar scroll;

    //public static Text reciveMessage;
    const int PORT = 11000;
    Client client;


    void Start()
    {
        Application.runInBackground = true;
        client = new Client(PORT, "211.238.13.182");
        //client = new Client(PORT, "192.168.0.45");
        //client = new Client(PORT, "192.168.1.101");
        client.Work();
        //sendMessage = forPrint;
        //txtName.text = "user";
        //txtMessage.text = "welcome";
    }

    public void PrintMessage()
    {
        //client.SendClientMessage(txtName.text + " : " + txtMessage.text);
        client.SendClientMessage("send client message");
        //scroll.value = 0;
    }

    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space))
        {
            PrintMessage();
        }
    }
}
